/**
 * MultiAI — Full-Stack Multimodal Assistant Client
 * Features: Real-time Chat, Image Analysis, PDF Comprehension, Voice Input/Output, Markdown/Code Highlighting
 */

// Application State
const state = {
    conversations: [],
    currentConversationId: null,
    currentMode: 'general', // 'general' | 'code' | 'writing' | 'translate'
    selectedFile: null,
    isGenerating: false,
    isListening: false,
    isSpeaking: false,
    currentlySpeakingMsgId: null,
    speechVoices: [],
    selectedVoiceURI: localStorage.getItem('multiai_voice') || '',
    speechRate: parseFloat(localStorage.getItem('multiai_speech_rate') || '1.0'),
    theme: localStorage.getItem('multiai_theme') || 'dark',
    apiConfigured: false,
    activeModel: 'gemini-2.5-flash'
};

// Mode metadata
const MODE_INFO = {
    general: { label: 'General Chat', icon: 'fa-brain', badge: 'General Mode' },
    code: { label: 'Code Assistant', icon: 'fa-code', badge: 'Code Assistant' },
    writing: { label: 'Writing & Essays', icon: 'fa-pen-nib', badge: 'Pro Writer' },
    translate: { label: 'Translator', icon: 'fa-language', badge: 'Universal Translator' }
};

// DOM Elements
const elements = {
    // Layout & Navigation
    sidebar: document.getElementById('sidebar'),
    sidebarOverlay: document.getElementById('sidebarOverlay'),
    openSidebarBtn: document.getElementById('openSidebarBtn'),
    closeSidebarBtn: document.getElementById('closeSidebarBtn'),
    newChatBtn: document.getElementById('newChatBtn'),
    conversationsList: document.getElementById('conversationsList'),
    chatCount: document.getElementById('chatCount'),
    historySearchInput: document.getElementById('historySearchInput'),
    currentChatTitle: document.getElementById('currentChatTitle'),
    editTitleBtn: document.getElementById('editTitleBtn'),
    activeModeBadge: document.getElementById('activeModeBadge'),
    themeToggleBtn: document.getElementById('themeToggleBtn'),
    themeIcon: document.getElementById('themeIcon'),
    themeLabel: document.getElementById('themeLabel'),
    openSettingsBtn: document.getElementById('openSettingsBtn'),
    navSettingsBtn: document.getElementById('navSettingsBtn'),
    clearChatBtn: document.getElementById('clearChatBtn'),
    exportChatBtn: document.getElementById('exportChatBtn'),
    
    // Status
    statusDot: document.getElementById('statusDot'),
    statusTitle: document.getElementById('statusTitle'),
    statusDesc: document.getElementById('statusDesc'),
    
    // Chat Scroll & Messages
    chatScrollArea: document.getElementById('chatScrollArea'),
    welcomeScreen: document.getElementById('welcomeScreen'),
    messagesContainer: document.getElementById('messagesContainer'),
    typingIndicator: document.getElementById('typingIndicator'),
    
    // Input Area
    chatForm: document.getElementById('chatForm'),
    messageInput: document.getElementById('messageInput'),
    sendBtn: document.getElementById('sendBtn'),
    attachBtn: document.getElementById('attachBtn'),
    fileInput: document.getElementById('fileInput'),
    voiceBtn: document.getElementById('voiceBtn'),
    
    // Mode selector in dock
    inputModeSelectBtn: document.getElementById('inputModeSelectBtn'),
    inputModeIcon: document.getElementById('inputModeIcon'),
    inputModeLabel: document.getElementById('inputModeLabel'),
    modeMenu: document.getElementById('modeMenu'),
    
    // Attachment preview
    attachmentPreview: document.getElementById('attachmentPreview'),
    previewThumb: document.getElementById('previewThumb'),
    previewFilename: document.getElementById('previewFilename'),
    previewFilesize: document.getElementById('previewFilesize'),
    removeAttachmentBtn: document.getElementById('removeAttachmentBtn'),
    
    // Voice Listening Banner
    voiceListeningBanner: document.getElementById('voiceListeningBanner'),
    cancelVoiceBtn: document.getElementById('cancelVoiceBtn'),
    
    // Global Speaking Bar
    globalSpeakingBar: document.getElementById('globalSpeakingBar'),
    stopSpeechBtn: document.getElementById('stopSpeechBtn'),
    
    // Settings Modal
    settingsModal: document.getElementById('settingsModal'),
    closeSettingsBtn: document.getElementById('closeSettingsBtn'),
    cancelSettingsBtn: document.getElementById('cancelSettingsBtn'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    apiKeyInput: document.getElementById('apiKeyInput'),
    toggleApiKeyVis: document.getElementById('toggleApiKeyVis'),
    pwdEyeIcon: document.getElementById('pwdEyeIcon'),
    modelSelect: document.getElementById('modelSelect'),
    voiceSelect: document.getElementById('voiceSelect'),
    voiceRate: document.getElementById('voiceRate'),
    voiceRateVal: document.getElementById('voiceRateVal'),
    
    // Lightbox
    imageLightbox: document.getElementById('imageLightbox'),
    lightboxImg: document.getElementById('lightboxImg'),
    lightboxCaption: document.getElementById('lightboxCaption'),
    closeLightboxBtn: document.getElementById('closeLightboxBtn'),
    
    // Toast Container
    toastContainer: document.getElementById('toastContainer')
};

// ===================================================================
// INITIALIZATION
// ===================================================================
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initMarkdownAndHighlighting();
    initSpeechSynthesis();
    initSpeechRecognition();
    setupEventListeners();
    checkApiStatus();
    loadConversations();
});

// Configure Marked.js for markdown rendering
function initMarkdownAndHighlighting() {
    if (typeof marked !== 'undefined') {
        marked.setOptions({
            renderer: new marked.Renderer(),
            highlight: function(code, lang) {
                if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
                    try {
                        return hljs.highlight(code, { language: lang }).value;
                    } catch (err) {
                        console.error('Highlight error:', err);
                    }
                }
                return code;
            },
            breaks: true,
            gfm: true
        });
    }
}

// Check backend status
async function checkApiStatus() {
    try {
        const res = await fetch('/api/status');
        const data = await res.json();
        state.apiConfigured = data.api_configured;
        state.activeModel = data.model || 'gemini-2.5-flash';
        
        if (elements.modelSelect) {
            elements.modelSelect.value = state.activeModel;
        }

        if (state.apiConfigured) {
            elements.statusDot.classList.add('online');
            elements.statusTitle.textContent = 'Gemini API Active';
            elements.statusDesc.textContent = state.activeModel;
        } else {
            elements.statusDot.classList.remove('online');
            elements.statusTitle.textContent = 'API Key Required';
            elements.statusDesc.textContent = 'Click to configure';
        }
    } catch (err) {
        console.warn('Backend status check failed:', err);
        elements.statusTitle.textContent = 'Backend Offline';
        elements.statusDesc.textContent = 'Check server status';
    }
}

// ===================================================================
// THEME MANAGEMENT
// ===================================================================
function initTheme() {
    applyTheme(state.theme);
}

function applyTheme(theme) {
    state.theme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('multiai_theme', theme);
    
    if (theme === 'light') {
        elements.themeIcon.className = 'fa-solid fa-sun';
        elements.themeLabel.textContent = 'Light Mode';
    } else {
        elements.themeIcon.className = 'fa-solid fa-moon';
        elements.themeLabel.textContent = 'Dark Mode';
    }
}

function toggleTheme() {
    const nextTheme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme(nextTheme);
}

// ===================================================================
// EVENT LISTENERS
// ===================================================================
function setupEventListeners() {
    // Theme toggle
    elements.themeToggleBtn.addEventListener('click', toggleTheme);

    // Sidebar Mobile
    elements.openSidebarBtn.addEventListener('click', () => {
        elements.sidebar.classList.add('open');
        elements.sidebarOverlay.classList.add('open');
    });
    elements.closeSidebarBtn.addEventListener('click', closeSidebar);
    elements.sidebarOverlay.addEventListener('click', closeSidebar);

    // New Chat
    elements.newChatBtn.addEventListener('click', createNewChat);

    // Keyboard Shortcuts
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            createNewChat();
        }
    });

    // History Search
    elements.historySearchInput.addEventListener('input', (e) => {
        filterConversations(e.target.value);
    });

    // Mode Selector Pills in Sidebar
    document.querySelectorAll('.mode-pill').forEach(btn => {
        btn.addEventListener('click', () => {
            const mode = btn.dataset.mode;
            setAiMode(mode);
        });
    });

    // Input mode dropdown in dock
    elements.inputModeSelectBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        elements.modeMenu.classList.toggle('hidden');
    });
    document.querySelectorAll('.mode-menu-item').forEach(item => {
        item.addEventListener('click', () => {
            const mode = item.dataset.mode;
            setAiMode(mode);
            elements.modeMenu.classList.add('hidden');
        });
    });
    document.addEventListener('click', () => {
        elements.modeMenu.classList.add('hidden');
    });

    // Chat Form & Auto-growing textarea
    elements.messageInput.addEventListener('input', handleTextareaInput);
    elements.messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (!state.isGenerating && (elements.messageInput.value.trim() || state.selectedFile)) {
                submitMessage();
            }
        }
    });
    elements.chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!state.isGenerating) {
            submitMessage();
        }
    });

    // File Attachment
    elements.attachBtn.addEventListener('click', () => elements.fileInput.click());
    elements.fileInput.addEventListener('change', handleFileSelected);
    elements.removeAttachmentBtn.addEventListener('click', clearAttachment);

    // Voice Input & Output
    elements.voiceBtn.addEventListener('click', toggleVoiceInput);
    elements.cancelVoiceBtn.addEventListener('click', stopVoiceInput);
    elements.stopSpeechBtn.addEventListener('click', stopSpeaking);

    // Editable Chat Title
    elements.editTitleBtn.addEventListener('click', startEditingTitle);
    elements.currentChatTitle.addEventListener('blur', finishEditingTitle);
    elements.currentChatTitle.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            elements.currentChatTitle.blur();
        }
    });

    // Top Navigation Actions
    elements.clearChatBtn.addEventListener('click', handleClearChat);
    elements.exportChatBtn.addEventListener('click', exportChatAsMarkdown);
    elements.openSettingsBtn.addEventListener('click', openSettingsModal);
    elements.navSettingsBtn.addEventListener('click', openSettingsModal);
    elements.closeSettingsBtn.addEventListener('click', closeSettingsModal);
    elements.cancelSettingsBtn.addEventListener('click', closeSettingsModal);
    elements.saveSettingsBtn.addEventListener('click', saveSettings);
    elements.toggleApiKeyVis.addEventListener('click', toggleApiKeyVisibility);
    elements.voiceRate.addEventListener('input', (e) => {
        elements.voiceRateVal.textContent = `${e.target.value}x`;
    });

    // Lightbox Modal
    elements.closeLightboxBtn.addEventListener('click', closeLightbox);
    elements.imageLightbox.addEventListener('click', (e) => {
        if (e.target === elements.imageLightbox) closeLightbox();
    });

    // Starter Cards
    document.querySelectorAll('.starter-card').forEach(card => {
        card.addEventListener('click', () => {
            const action = card.dataset.action;
            handleStarterCardAction(action);
        });
    });

    // Status card click -> opens settings
    document.getElementById('apiStatusCard').addEventListener('click', openSettingsModal);
}

function closeSidebar() {
    elements.sidebar.classList.remove('open');
    elements.sidebarOverlay.classList.remove('open');
}

function handleTextareaInput() {
    const el = elements.messageInput;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 180) + 'px';
    
    // Enable or disable send button
    const hasContent = el.value.trim().length > 0 || state.selectedFile !== null;
    elements.sendBtn.disabled = !hasContent || state.isGenerating;
}

function setAiMode(mode) {
    if (!MODE_INFO[mode]) mode = 'general';
    state.currentMode = mode;

    // Update Sidebar pills
    document.querySelectorAll('.mode-pill').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.mode === mode);
    });

    // Update Input bar dropdown button
    const info = MODE_INFO[mode];
    elements.inputModeIcon.className = `fa-solid ${info.icon}`;
    elements.inputModeLabel.textContent = info.label.split(' ')[0];

    // Update Header Badge
    elements.activeModeBadge.innerHTML = `<i class="fa-solid ${info.icon}"></i> <span>${info.badge}</span>`;
    
    showToast(`Switched to ${info.label}`, 'info');
}

// ===================================================================
// FILE ATTACHMENT HANDLING
// ===================================================================
function handleFileSelected(e) {
    const file = e.target.files[0];
    if (!file) return;

    // Validate size (max 16MB)
    const maxSize = 16 * 1024 * 1024;
    if (file.size > maxSize) {
        showToast('File size exceeds 16MB limit.', 'error');
        elements.fileInput.value = '';
        return;
    }

    // Validate extension
    const validExtensions = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];
    const ext = file.name.split('.').pop().toLowerCase();
    if (!validExtensions.includes(ext)) {
        showToast('Only JPG, PNG, WEBP, and PDF files are supported.', 'error');
        elements.fileInput.value = '';
        return;
    }

    state.selectedFile = file;

    // Display Preview Drawer
    elements.previewFilename.textContent = file.name;
    elements.previewFilesize.textContent = formatFileSize(file.size);

    if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
            elements.previewThumb.innerHTML = `<img src="${event.target.result}" alt="Preview">`;
        };
        reader.readAsDataURL(file);
    } else {
        // PDF Icon
        elements.previewThumb.innerHTML = `<i class="fa-solid fa-file-pdf" style="color: #ef4444;"></i>`;
    }

    elements.attachmentPreview.classList.remove('hidden');
    handleTextareaInput();
}

function clearAttachment() {
    state.selectedFile = null;
    elements.fileInput.value = '';
    elements.previewThumb.innerHTML = '';
    elements.attachmentPreview.classList.add('hidden');
    handleTextareaInput();
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
}

// Starter Card Actions
function handleStarterCardAction(action) {
    if (action === 'upload-pdf') {
        elements.fileInput.accept = '.pdf';
        elements.fileInput.click();
        elements.fileInput.accept = '.jpg,.jpeg,.png,.webp,.pdf';
    } else if (action === 'upload-image') {
        elements.fileInput.accept = '.jpg,.jpeg,.png,.webp';
        elements.fileInput.click();
        elements.fileInput.accept = '.jpg,.jpeg,.png,.webp,.pdf';
    } else if (action === 'prompt-code') {
        setAiMode('code');
        elements.messageInput.value = 'Write a Python script that analyzes web traffic logs and finds the most frequent endpoints.';
        elements.messageInput.focus();
        handleTextareaInput();
    } else if (action === 'prompt-writer') {
        setAiMode('writing');
        elements.messageInput.value = 'Draft a professional and persuasive project kickoff email to a remote engineering team.';
        elements.messageInput.focus();
        handleTextareaInput();
    }
}

// ===================================================================
// SPEECH RECOGNITION (VOICE INPUT)
// ===================================================================
let speechRecognitionInstance = null;

function initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        console.warn('SpeechRecognition API is not supported in this browser.');
        elements.voiceBtn.title = 'Voice input not supported in this browser';
        return;
    }

    speechRecognitionInstance = new SpeechRecognition();
    speechRecognitionInstance.continuous = false;
    speechRecognitionInstance.interimResults = true;
    speechRecognitionInstance.lang = 'en-US';

    speechRecognitionInstance.onstart = () => {
        state.isListening = true;
        elements.voiceBtn.classList.add('recording');
        elements.voiceListeningBanner.classList.remove('hidden');
        elements.messageInput.placeholder = 'Listening to your speech... Speak now.';
    };

    speechRecognitionInstance.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
        }
        elements.messageInput.value = transcript;
        handleTextareaInput();
    };

    speechRecognitionInstance.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        showToast(`Voice error: ${event.error}`, 'error');
        stopVoiceInput();
    };

    speechRecognitionInstance.onend = () => {
        stopVoiceInput();
    };
}

function toggleVoiceInput() {
    if (!speechRecognitionInstance) {
        showToast('Speech recognition is not supported in this browser. Please use Chrome or Edge.', 'error');
        return;
    }

    if (state.isListening) {
        speechRecognitionInstance.stop();
    } else {
        try {
            speechRecognitionInstance.start();
        } catch (err) {
            console.error('Failed to start speech recognition:', err);
        }
    }
}

function stopVoiceInput() {
    state.isListening = false;
    elements.voiceBtn.classList.remove('recording');
    elements.voiceListeningBanner.classList.add('hidden');
    elements.messageInput.placeholder = 'Message MultiAI or ask about an image/PDF...';
}

// ===================================================================
// SPEECH SYNTHESIS (VOICE OUTPUT)
// ===================================================================
function initSpeechSynthesis() {
    if (!('speechSynthesis' in window)) {
        console.warn('SpeechSynthesis API is not supported in this browser.');
        return;
    }

    function populateVoices() {
        state.speechVoices = window.speechSynthesis.getVoices();
        if (!elements.voiceSelect) return;
        
        elements.voiceSelect.innerHTML = '<option value="">Default System Voice</option>';
        state.speechVoices.forEach(voice => {
            const opt = document.createElement('option');
            opt.value = voice.voiceURI;
            opt.textContent = `${voice.name} (${voice.lang})${voice.default ? ' [Default]' : ''}`;
            if (voice.voiceURI === state.selectedVoiceURI) {
                opt.selected = true;
            }
            elements.voiceSelect.appendChild(opt);
        });
    }

    populateVoices();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = populateVoices;
    }
}

function speakText(text, msgId = null) {
    if (!('speechSynthesis' in window)) {
        showToast('Speech synthesis is not supported in this browser.', 'error');
        return;
    }

    stopSpeaking();

    // Clean markdown syntax for natural speech
    const cleanSpeech = text
        .replace(/```[\s\S]*?```/g, ' Code snippet omitted. ')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/[*_#~>]/g, '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/\n+/g, ' ')
        .trim();

    if (!cleanSpeech) return;

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.rate = state.speechRate;

    if (state.selectedVoiceURI) {
        const voice = state.speechVoices.find(v => v.voiceURI === state.selectedVoiceURI);
        if (voice) utterance.voice = voice;
    }

    utterance.onstart = () => {
        state.isSpeaking = true;
        state.currentlySpeakingMsgId = msgId;
        elements.globalSpeakingBar.classList.remove('hidden');
        updateSpeakButtonUI(msgId, true);
    };

    utterance.onend = () => {
        resetSpeakingState();
    };

    utterance.onerror = () => {
        resetSpeakingState();
    };

    window.speechSynthesis.speak(utterance);
}

function stopSpeaking() {
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
    }
    resetSpeakingState();
}

function resetSpeakingState() {
    state.isSpeaking = false;
    if (state.currentlySpeakingMsgId) {
        updateSpeakButtonUI(state.currentlySpeakingMsgId, false);
    }
    state.currentlySpeakingMsgId = null;
    elements.globalSpeakingBar.classList.add('hidden');
}

function updateSpeakButtonUI(msgId, isReading) {
    const btn = document.querySelector(`.msg-speak-btn[data-msg-id="${msgId}"]`);
    if (btn) {
        if (isReading) {
            btn.innerHTML = `<i class="fa-solid fa-volume-xmark"></i> Stop`;
            btn.classList.add('active-speaking');
        } else {
            btn.innerHTML = `<i class="fa-solid fa-volume-high"></i> Read`;
            btn.classList.remove('active-speaking');
        }
    }
}

// ===================================================================
// CONVERSATIONS & CHAT HISTORY
// ===================================================================
async function loadConversations() {
    try {
        const res = await fetch('/api/conversations');
        const data = await res.json();
        state.conversations = data.conversations || [];
        renderConversationsList();

        // If there's an existing conversation, open the first one; else show welcome screen
        if (state.conversations.length > 0 && !state.currentConversationId) {
            openConversation(state.conversations[0].id);
        } else if (!state.currentConversationId) {
            showWelcomeScreen();
        }
    } catch (err) {
        console.error('Error fetching conversations:', err);
    }
}

function renderConversationsList(filterQuery = '') {
    elements.conversationsList.innerHTML = '';
    const filtered = state.conversations.filter(c => 
        c.title.toLowerCase().includes(filterQuery.toLowerCase())
    );

    elements.chatCount.textContent = state.conversations.length;

    if (filtered.length === 0) {
        elements.conversationsList.innerHTML = `
            <div class="empty-history-text">
                ${filterQuery ? 'No matching conversations' : 'No conversations yet'}
            </div>
        `;
        return;
    }

    filtered.forEach(conv => {
        const item = document.createElement('div');
        item.className = `conv-item ${conv.id === state.currentConversationId ? 'active' : ''}`;
        item.dataset.id = conv.id;

        item.innerHTML = `
            <i class="fa-regular fa-message conv-icon"></i>
            <span class="conv-title" title="${escapeHtml(conv.title)}">${escapeHtml(conv.title)}</span>
            <div class="conv-actions">
                <button class="conv-action-btn rename-btn" title="Rename chat">
                    <i class="fa-solid fa-pen"></i>
                </button>
                <button class="conv-action-btn delete-btn" title="Delete chat">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            </div>
        `;

        // Click to open
        item.addEventListener('click', (e) => {
            if (!e.target.closest('.conv-actions')) {
                openConversation(conv.id);
                closeSidebar();
            }
        });

        // Rename
        item.querySelector('.rename-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            promptRenameConversation(conv.id, conv.title);
        });

        // Delete
        item.querySelector('.delete-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            confirmDeleteConversation(conv.id);
        });

        elements.conversationsList.appendChild(item);
    });
}

function filterConversations(query) {
    renderConversationsList(query);
}

function createNewChat() {
    stopSpeaking();
    state.currentConversationId = null;
    elements.currentChatTitle.textContent = 'New Chat';
    elements.messagesContainer.innerHTML = '';
    showWelcomeScreen();
    clearAttachment();
    elements.messageInput.value = '';
    handleTextareaInput();
    renderConversationsList();
    closeSidebar();
}

async function openConversation(convId) {
    stopSpeaking();
    state.currentConversationId = convId;
    renderConversationsList();

    try {
        const res = await fetch(`/api/conversations/${convId}`);
        if (!res.ok) throw new Error('Failed to load conversation');
        const conv = await res.json();

        elements.currentChatTitle.textContent = conv.title || 'Untitled Chat';
        hideWelcomeScreen();
        elements.messagesContainer.innerHTML = '';

        if (conv.messages && conv.messages.length > 0) {
            conv.messages.forEach(msg => {
                renderMessageBubble(msg);
            });
            scrollToBottom();
        } else {
            showWelcomeScreen();
        }
    } catch (err) {
        showToast('Error loading chat messages', 'error');
        console.error(err);
    }
}

async function promptRenameConversation(convId, oldTitle) {
    const newTitle = prompt('Enter new conversation title:', oldTitle);
    if (!newTitle || newTitle.trim() === '' || newTitle.trim() === oldTitle) return;

    try {
        const res = await fetch(`/api/conversations/${convId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: newTitle.trim() })
        });
        if (res.ok) {
            if (state.currentConversationId === convId) {
                elements.currentChatTitle.textContent = newTitle.trim();
            }
            await loadConversations();
            showToast('Conversation renamed', 'success');
        } else {
            showToast('Failed to rename conversation', 'error');
        }
    } catch (err) {
        showToast('Error updating conversation', 'error');
    }
}

async function confirmDeleteConversation(convId) {
    if (!confirm('Are you sure you want to delete this conversation?')) return;

    try {
        const res = await fetch(`/api/conversations/${convId}`, { method: 'DELETE' });
        if (res.ok) {
            if (state.currentConversationId === convId) {
                createNewChat();
            }
            await loadConversations();
            showToast('Conversation deleted', 'success');
        } else {
            showToast('Failed to delete conversation', 'error');
        }
    } catch (err) {
        showToast('Error deleting conversation', 'error');
    }
}

function startEditingTitle() {
    elements.currentChatTitle.setAttribute('contenteditable', 'true');
    elements.currentChatTitle.focus();
}

async function finishEditingTitle() {
    elements.currentChatTitle.setAttribute('contenteditable', 'false');
    const newTitle = elements.currentChatTitle.textContent.trim();
    if (!newTitle || !state.currentConversationId) return;

    try {
        await fetch(`/api/conversations/${state.currentConversationId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: newTitle })
        });
        await loadConversations();
    } catch (err) {
        console.error('Failed to update title:', err);
    }
}

function handleClearChat() {
    if (!state.currentConversationId) {
        elements.messagesContainer.innerHTML = '';
        showWelcomeScreen();
        return;
    }
    if (confirm('Are you sure you want to clear all messages in this conversation?')) {
        confirmDeleteConversation(state.currentConversationId);
    }
}

function exportChatAsMarkdown() {
    if (!state.currentConversationId) {
        showToast('No active conversation to export', 'info');
        return;
    }
    
    const messages = elements.messagesContainer.querySelectorAll('.message-row');
    if (messages.length === 0) {
        showToast('Conversation is empty', 'info');
        return;
    }

    let md = `# ${elements.currentChatTitle.textContent}\nExported on: ${new Date().toLocaleString()}\n\n---\n\n`;
    
    messages.forEach(row => {
        const isUser = row.classList.contains('user');
        const role = isUser ? 'User' : 'MultiAI';
        const bubble = row.querySelector(isUser ? '.user-bubble' : '.assistant-bubble');
        const content = bubble ? bubble.innerText : '';
        md += `### ${role}:\n${content}\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${elements.currentChatTitle.textContent.replace(/[^a-z0-9]/gi, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Conversation exported successfully', 'success');
}

// ===================================================================
// SEND MESSAGE & CHAT EXECUTION
// ===================================================================
async function submitMessage() {
    const text = elements.messageInput.value.trim();
    const file = state.selectedFile;

    if (!text && !file) return;

    hideWelcomeScreen();
    setGeneratingState(true);

    // Optimistically render User Message Bubble
    const tempUserMsg = {
        id: 'temp_user_' + Date.now(),
        role: 'user',
        content: text,
        attachment_path: file ? URL.createObjectURL(file) : null,
        attachment_type: file ? (file.type.startsWith('image/') ? 'image' : 'pdf') : null,
        attachment_name: file ? file.name : null,
        isTemp: true
    };
    renderMessageBubble(tempUserMsg);
    scrollToBottom();

    // Prepare FormData
    const formData = new FormData();
    if (state.currentConversationId) {
        formData.append('conversation_id', state.currentConversationId);
    }
    formData.append('message', text);
    formData.append('mode', state.currentMode);
    if (file) {
        formData.append('file', file);
    }

    // Reset input fields
    elements.messageInput.value = '';
    clearAttachment();

    // Show Thinking / Typing Indicator
    showTypingIndicator();
    scrollToBottom();

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        hideTypingIndicator();

        if (!response.ok) {
            throw new Error(data.error || 'Server error occurred');
        }

        // Set conversation ID
        state.currentConversationId = data.conversation_id;

        // Render AI Message Bubble
        renderMessageBubble(data.ai_message);
        scrollToBottom();

        // Refresh conversation history in sidebar
        await loadConversations();

    } catch (err) {
        hideTypingIndicator();
        console.error('Chat error:', err);
        showToast(err.message || 'Failed to generate AI response.', 'error');

        // Render error bubble in chat
        renderMessageBubble({
            id: 'err_' + Date.now(),
            role: 'assistant',
            content: `⚠️ **Error:** ${err.message || 'Could not complete request. Please verify your Gemini API key and connection.'}`
        });
        scrollToBottom();
    } finally {
        setGeneratingState(false);
        elements.messageInput.focus();
    }
}

function setGeneratingState(generating) {
    state.isGenerating = generating;
    elements.sendBtn.disabled = generating;
    elements.sendBtn.innerHTML = generating 
        ? `<i class="fa-solid fa-spinner fa-spin"></i>` 
        : `<i class="fa-solid fa-arrow-up"></i>`;
}

function showTypingIndicator() {
    elements.typingIndicator.classList.remove('hidden');
}

function hideTypingIndicator() {
    elements.typingIndicator.classList.add('hidden');
}

function showWelcomeScreen() {
    elements.welcomeScreen.classList.remove('hidden');
}

function hideWelcomeScreen() {
    elements.welcomeScreen.classList.add('hidden');
}

function scrollToBottom() {
    setTimeout(() => {
        elements.chatScrollArea.scrollTop = elements.chatScrollArea.scrollHeight;
    }, 50);
}

// ===================================================================
// MESSAGE BUBBLE RENDERING
// ===================================================================
function renderMessageBubble(msg) {
    const isUser = msg.role === 'user';
    const row = document.createElement('div');
    row.className = `message-row ${isUser ? 'user' : 'assistant'}`;
    row.dataset.id = msg.id;

    // Avatar
    const avatar = document.createElement('div');
    avatar.className = isUser ? 'user-avatar' : 'assistant-avatar';
    avatar.innerHTML = isUser ? `<i class="fa-regular fa-user"></i>` : `<i class="fa-solid fa-sparkles"></i>`;

    // Content Wrapper
    const contentWrapper = document.createElement('div');
    contentWrapper.className = 'message-content-wrapper';

    // Attachment Display
    if (msg.attachment_path) {
        const attachCard = document.createElement('div');
        attachCard.className = 'message-attachment-card';

        if (msg.attachment_type === 'image') {
            const img = document.createElement('img');
            img.src = msg.attachment_path;
            img.className = 'message-image-preview';
            img.alt = msg.attachment_name || 'Uploaded Image';
            img.addEventListener('click', () => openLightbox(msg.attachment_path, msg.attachment_name));
            attachCard.appendChild(img);
        } else if (msg.attachment_type === 'pdf') {
            const pdfCard = document.createElement('a');
            pdfCard.href = msg.attachment_path;
            pdfCard.target = '_blank';
            pdfCard.className = 'message-pdf-card';
            pdfCard.innerHTML = `
                <div class="pdf-badge-icon">
                    <i class="fa-solid fa-file-pdf"></i>
                </div>
                <div class="pdf-meta">
                    <span class="pdf-filename">${escapeHtml(msg.attachment_name || 'Document.pdf')}</span>
                    <span class="pdf-label">PDF Document (Click to view)</span>
                </div>
            `;
            attachCard.appendChild(pdfCard);
        }
        contentWrapper.appendChild(attachCard);
    }

    // Message Bubble Body
    const bubble = document.createElement('div');
    bubble.className = isUser ? 'user-bubble' : 'assistant-bubble';

    if (isUser) {
        bubble.textContent = msg.content;
    } else {
        // Markdown parsing for assistant
        const rawHtml = typeof marked !== 'undefined' ? marked.parse(msg.content || '') : msg.content;
        const cleanHtml = typeof DOMPurify !== 'undefined' ? DOMPurify.sanitize(rawHtml) : rawHtml;
        bubble.innerHTML = cleanHtml;

        // Enhance code blocks with copy buttons and language headers
        bubble.querySelectorAll('pre code').forEach((codeBlock) => {
            const pre = codeBlock.parentElement;
            const langClass = Array.from(codeBlock.classList).find(c => c.startsWith('language-'));
            const lang = langClass ? langClass.replace('language-', '') : 'code';

            const container = document.createElement('div');
            container.className = 'code-block-container';
            container.innerHTML = `
                <div class="code-header">
                    <span class="code-lang">${lang}</span>
                    <button class="copy-code-btn" type="button">
                        <i class="fa-regular fa-copy"></i> Copy
                    </button>
                </div>
            `;

            pre.parentNode.insertBefore(container, pre);
            container.appendChild(pre);

            const copyBtn = container.querySelector('.copy-code-btn');
            copyBtn.addEventListener('click', () => {
                navigator.clipboard.writeText(codeBlock.innerText).then(() => {
                    copyBtn.innerHTML = `<i class="fa-solid fa-check"></i> Copied!`;
                    setTimeout(() => {
                        copyBtn.innerHTML = `<i class="fa-regular fa-copy"></i> Copy`;
                    }, 2000);
                });
            });
        });
    }

    contentWrapper.appendChild(bubble);

    // Assistant Action Toolbar (Read Aloud, Copy, Regenerate)
    if (!isUser) {
        const toolbar = document.createElement('div');
        toolbar.className = 'message-actions-toolbar';

        // Read Aloud / Speak
        const speakBtn = document.createElement('button');
        speakBtn.className = 'msg-action-btn msg-speak-btn';
        speakBtn.dataset.msgId = msg.id;
        speakBtn.innerHTML = `<i class="fa-solid fa-volume-high"></i> Read`;
        speakBtn.addEventListener('click', () => {
            if (state.isSpeaking && state.currentlySpeakingMsgId === msg.id) {
                stopSpeaking();
            } else {
                speakText(msg.content, msg.id);
            }
        });
        toolbar.appendChild(speakBtn);

        // Copy
        const copyBtn = document.createElement('button');
        copyBtn.className = 'msg-action-btn';
        copyBtn.innerHTML = `<i class="fa-regular fa-copy"></i> Copy`;
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(msg.content).then(() => {
                showToast('Response copied to clipboard', 'success');
            });
        });
        toolbar.appendChild(copyBtn);

        contentWrapper.appendChild(toolbar);
    }

    row.appendChild(avatar);
    row.appendChild(contentWrapper);
    elements.messagesContainer.appendChild(row);
}

// ===================================================================
// IMAGE LIGHTBOX
// ===================================================================
function openLightbox(url, name) {
    elements.lightboxImg.src = url;
    elements.lightboxCaption.textContent = name || 'Image Preview';
    elements.imageLightbox.classList.remove('hidden');
}

function closeLightbox() {
    elements.imageLightbox.classList.add('hidden');
    elements.lightboxImg.src = '';
}

// ===================================================================
// SETTINGS MODAL
// ===================================================================
function openSettingsModal() {
    elements.settingsModal.classList.remove('hidden');
    elements.apiKeyInput.focus();
}

function closeSettingsModal() {
    elements.settingsModal.classList.add('hidden');
}

function toggleApiKeyVisibility() {
    const isPassword = elements.apiKeyInput.type === 'password';
    elements.apiKeyInput.type = isPassword ? 'text' : 'password';
    elements.pwdEyeIcon.className = isPassword ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
}

async function saveSettings() {
    const key = elements.apiKeyInput.value.trim();
    const model = elements.modelSelect.value;
    const voiceURI = elements.voiceSelect.value;
    const rate = parseFloat(elements.voiceRate.value);

    // Save Voice Settings to localStorage
    state.selectedVoiceURI = voiceURI;
    state.speechRate = rate;
    localStorage.setItem('multiai_voice', voiceURI);
    localStorage.setItem('multiai_speech_rate', rate.toString());

    try {
        const res = await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                api_key: key,
                model: model
            })
        });

        const data = await res.json();
        if (data.success) {
            state.apiConfigured = data.api_configured;
            state.activeModel = data.model;
            showToast('Settings saved successfully!', 'success');
            checkApiStatus();
            closeSettingsModal();
        } else {
            showToast('Failed to save settings.', 'error');
        }
    } catch (err) {
        showToast('Error connecting to settings endpoint.', 'error');
    }
}

// ===================================================================
// TOAST NOTIFICATIONS
// ===================================================================
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let iconClass = 'fa-circle-info';
    if (type === 'success') iconClass = 'fa-circle-check';
    if (type === 'error') iconClass = 'fa-circle-exclamation';

    toast.innerHTML = `
        <i class="fa-solid ${iconClass}"></i>
        <span>${escapeHtml(message)}</span>
    `;

    elements.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 250);
    }, 3200);
}

// Utility: HTML Escaper
function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
